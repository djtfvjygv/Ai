package com.axiom.local

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

private val Bg = Color(0xFF080C14)
private val Panel = Color(0xFF111A28)
private val Panel2 = Color(0xFF172438)
private val Cyan = Color(0xFF75E2DF)
private val TextMain = Color(0xFFE8EEF8)
private val Muted = Color(0xFF91A0B5)
private val Purple = Color(0xFFA89BFF)

data class ChatMessage(val role: String, val content: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AxiomApp(applicationContext) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AxiomApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("axiom_settings", Context.MODE_PRIVATE) }
    var endpoint by remember { mutableStateOf(prefs.getString("endpoint", "http://192.168.1.100:11434") ?: "") }
    var model by remember { mutableStateOf(prefs.getString("model", "llama3.2:3b") ?: "llama3.2:3b") }
    var draft by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(loadMessages(prefs)) }
    var isBusy by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showClearConfirm by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Chưa kiểm tra kết nối") }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan,
            background = Bg,
            surface = Panel,
            onBackground = TextMain,
            onSurface = TextMain
        )
    ) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("AXIOM", color = TextMain, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                            Text("LOCAL INTELLIGENCE  ·  ${model.uppercase()}", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
                        }
                    },
                    actions = {
                        IconButton(onClick = { showClearConfirm = true }) {
                            Icon(Icons.Default.Delete, contentDescription = "Xóa hội thoại", tint = Muted)
                        }
                        IconButton(onClick = { showSettings = true }) {
                            Icon(Icons.Default.Settings, contentDescription = "Cài đặt", tint = Cyan)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg)
                )
            },
            bottomBar = {
                Column(
                    Modifier.fillMaxWidth().background(Bg).padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 12.dp)
                ) {
                    Row(
                        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(10.dp),
                        verticalAlignment = Alignment.Bottom
                    ) {
                        BasicTextField(
                            value = draft,
                            onValueChange = { draft = it.take(12000) },
                            modifier = Modifier.weight(1f).padding(horizontal = 8.dp, vertical = 10.dp),
                            textStyle = androidx.compose.ui.text.TextStyle(color = TextMain, fontSize = 15.sp),
                            cursorBrush = androidx.compose.ui.graphics.SolidColor(Cyan),
                            minLines = 1,
                            maxLines = 5,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(onSend = {
                                if (draft.isNotBlank() && !isBusy) {
                                    val prompt = draft.trim()
                                    draft = ""
                                    sendMessage(prompt, messages, endpoint, model, prefs,
                                        onMessages = { messages = it },
                                        onBusy = { isBusy = it },
                                        onStatus = { status = it },
                                        scope = scope
                                    )
                                }
                            }),
                            decorationBox = { inner ->
                                Box {
                                    if (draft.isEmpty()) Text("Nhập câu hỏi…", color = Muted)
                                    inner()
                                }
                            }
                        )
                        Spacer(Modifier.width(8.dp))
                        IconButton(
                            onClick = {
                                val prompt = draft.trim()
                                if (prompt.isNotEmpty() && !isBusy) {
                                    draft = ""
                                    sendMessage(prompt, messages, endpoint, model, prefs,
                                        onMessages = { messages = it },
                                        onBusy = { isBusy = it },
                                        onStatus = { status = it },
                                        scope = scope
                                    )
                                }
                            },
                            enabled = draft.isNotBlank() && !isBusy,
                            modifier = Modifier.background(Cyan, CircleShape).size(42.dp)
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Gửi", tint = Bg)
                        }
                    }
                    Text("AI chạy qua máy chủ Ollama do bạn cấu hình · $status", color = Muted, fontSize = 10.sp,
                        modifier = Modifier.padding(start = 8.dp, top = 6.dp))
                }
            }
        ) { padding ->
            if (messages.isEmpty()) {
                Column(
                    Modifier.fillMaxSize().padding(padding).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(Modifier.size(76.dp).background(Panel2, CircleShape), contentAlignment = Alignment.Center) {
                        Text("A", color = Cyan, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(22.dp))
                    Text("Xin chào. Tôi là Axiom.", color = TextMain, fontSize = 23.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    Text("Trợ lý AI riêng tư kết nối mô hình local của bạn.", color = Muted)
                    Spacer(Modifier.height(22.dp))
                    Suggestion("Giải thích REST API bằng ví dụ Kotlin") { draft = "Giải thích REST API bằng ví dụ Kotlin." }
                    Suggestion("Lập checklist bảo mật ứng dụng web") { draft = "Lập checklist bảo mật cho một ứng dụng web cá nhân." }
                    Suggestion("Phân tích và sửa lỗi đoạn code") { draft = "Hãy phân tích đoạn code sau, tìm lỗi và đề xuất cách sửa an toàn: " }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(messages) { message -> MessageBubble(message) }
                    if (isBusy) item { MessageBubble(ChatMessage("assistant", "Đang suy nghĩ…")) }
                }
                LaunchedEffect(messages.size, isBusy) {
                    if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
                }
            }
        }
    }

    if (showSettings) {
        SettingsDialog(
            initialEndpoint = endpoint,
            initialModel = model,
            onDismiss = { showSettings = false },
            onSave = { newEndpoint, newModel ->
                endpoint = newEndpoint.trim().trimEnd('/')
                model = newModel.trim()
                prefs.edit().putString("endpoint", endpoint).putString("model", model).apply()
                showSettings = false
            },
            onTest = { testEndpoint, testModel ->
                scope.launch {
                    status = "Đang kiểm tra…"
                    status = try {
                        withContext(Dispatchers.IO) { testOllama(testEndpoint.trim().trimEnd('/'), testModel.trim()) }
                        "Kết nối thành công"
                    } catch (e: Exception) {
                        "Lỗi kết nối: ${e.message ?: "không xác định"}"
                    }
                }
            }
        )
    }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            title = { Text("Xóa cuộc trò chuyện?") },
            text = { Text("Toàn bộ lịch sử đã lưu trên ứng dụng sẽ bị xóa.") },
            confirmButton = {
                TextButton(onClick = {
                    messages = emptyList()
                    saveMessages(prefs, messages)
                    showClearConfirm = false
                }) { Text("Xóa", color = Cyan) }
            },
            dismissButton = { TextButton(onClick = { showClearConfirm = false }) { Text("Hủy") } },
            containerColor = Panel
        )
    }
}

@Composable
private fun Suggestion(label: String, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { onClick() },
        color = Panel, shape = RoundedCornerShape(12.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Panel2)
    ) {
        Text(label, color = TextMain, modifier = Modifier.padding(13.dp), fontSize = 13.sp)
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val user = message.role == "user"
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (user) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Top
    ) {
        if (!user) {
            Box(Modifier.size(30.dp).background(Panel2, RoundedCornerShape(9.dp)), contentAlignment = Alignment.Center) {
                Text("AX", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(8.dp))
        }
        Surface(
            color = if (user) Color(0xFF24223A) else Panel,
            shape = RoundedCornerShape(14.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, if (user) Color(0xFF40395E) else Panel2),
            modifier = Modifier.widthIn(max = 310.dp)
        ) {
            Text(message.content, color = TextMain, modifier = Modifier.padding(13.dp), fontSize = 14.sp)
        }
        if (user) {
            Spacer(Modifier.width(8.dp))
            Box(Modifier.size(30.dp).background(Color(0xFF292344), RoundedCornerShape(9.dp)), contentAlignment = Alignment.Center) {
                Text("YOU", color = Purple, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun SettingsDialog(
    initialEndpoint: String,
    initialModel: String,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit,
    onTest: (String, String) -> Unit
) {
    var endpoint by remember { mutableStateOf(initialEndpoint) }
    var model by remember { mutableStateOf(initialModel) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("Cài đặt AI", color = TextMain) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Địa chỉ Ollama", color = Muted, fontSize = 12.sp)
                OutlinedTextField(value = endpoint, onValueChange = { endpoint = it },
                    placeholder = { Text("http://192.168.1.10:11434") }, singleLine = true)
                Text("Tên model đã tải", color = Muted, fontSize = 12.sp)
                OutlinedTextField(value = model, onValueChange = { model = it }, singleLine = true)
                Text("Ví dụ: llama3.2:3b hoặc qwen2.5:3b", color = Muted, fontSize = 11.sp)
                TextButton(onClick = { onTest(endpoint, model) }) { Text("Kiểm tra kết nối", color = Cyan) }
            }
        },
        confirmButton = { TextButton(onClick = { onSave(endpoint, model) }) { Text("Lưu", color = Cyan) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Đóng", color = Muted) } }
    )
}

private fun sendMessage(
    prompt: String,
    oldMessages: List<ChatMessage>,
    endpoint: String,
    model: String,
    prefs: android.content.SharedPreferences,
    onMessages: (List<ChatMessage>) -> Unit,
    onBusy: (Boolean) -> Unit,
    onStatus: (String) -> Unit,
    scope: kotlinx.coroutines.CoroutineScope
) {
    val updated = oldMessages + ChatMessage("user", prompt)
    onMessages(updated)
    saveMessages(prefs, updated)
    onBusy(true)
    onStatus("Đang gửi yêu cầu")
    scope.launch {
        try {
            val reply = withContext(Dispatchers.IO) {
                askOllama(endpoint.trim().trimEnd('/'), model.trim(), updated)
            }
            val result = updated + ChatMessage("assistant", reply)
            onMessages(result)
            saveMessages(prefs, result)
            onStatus("Đã kết nối")
        } catch (e: Exception) {
            val error = "Không thể nhận phản hồi: ${e.message ?: "lỗi không xác định"}\n\nKiểm tra địa chỉ Ollama, mạng Wi-Fi và model đã tải."
            val result = updated + ChatMessage("assistant", error)
            onMessages(result)
            saveMessages(prefs, result)
            onStatus("Lỗi kết nối")
        } finally {
            onBusy(false)
        }
    }
}

private fun askOllama(endpoint: String, model: String, history: List<ChatMessage>): String {
    require(endpoint.startsWith("http://") || endpoint.startsWith("https://")) { "Địa chỉ phải bắt đầu bằng http:// hoặc https://" }
    require(model.isNotBlank()) { "Tên model không được để trống" }

    val messages = JSONArray()
    messages.put(JSONObject().put("role", "system").put("content",
        """Bạn là AXIOM, trợ lý AI nghiên cứu và lập trình an toàn. Trả lời bằng ngôn ngữ người dùng. Hỗ trợ giải thích code, sửa lỗi, phòng thủ và kiểm thử trong môi trường được phép. Không hướng dẫn đánh cắp dữ liệu, phát tán mã độc, né tránh phát hiện hoặc tấn công hệ thống không được phép. Khi yêu cầu nguy hiểm, từ chối ngắn gọn và đề xuất hướng phòng thủ."""))
    history.takeLast(24).forEach {
        messages.put(JSONObject().put("role", it.role).put("content", it.content))
    }
    val body = JSONObject().put("model", model).put("messages", messages).put("stream", false)
        .put("options", JSONObject().put("temperature", 0.6).put("num_ctx", 8192))
    val request = Request.Builder()
        .url("$endpoint/api/chat")
        .post(body.toString().toRequestBody("application/json".toMediaType()))
        .build()
    val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .callTimeout(190, TimeUnit.SECONDS)
        .build()
    client.newCall(request).execute().use { response ->
        val raw = response.body?.string().orEmpty()
        if (!response.isSuccessful) throw IllegalStateException("HTTP ${response.code}: ${raw.take(300)}")
        val content = JSONObject(raw).optJSONObject("message")?.optString("content").orEmpty().trim()
        if (content.isBlank()) throw IllegalStateException("Model trả về nội dung trống")
        return content
    }
}

private fun testOllama(endpoint: String, model: String) {
    require(endpoint.startsWith("http://") || endpoint.startsWith("https://")) { "URL không hợp lệ" }
    val request = Request.Builder().url("$endpoint/api/tags").get().build()
    val client = OkHttpClient.Builder().connectTimeout(5, TimeUnit.SECONDS).readTimeout(8, TimeUnit.SECONDS).build()
    client.newCall(request).execute().use { response ->
        if (!response.isSuccessful) throw IllegalStateException("HTTP ${response.code}")
        val models = JSONObject(response.body?.string().orEmpty()).optJSONArray("models") ?: JSONArray()
        val found = (0 until models.length()).any { i ->
            models.optJSONObject(i)?.optString("name")?.let { it == model || it.startsWith("$model:") } == true
        }
        if (!found) throw IllegalStateException("Đã kết nối Ollama nhưng chưa thấy model '$model'. Hãy tải model trước.")
    }
}

private fun saveMessages(prefs: android.content.SharedPreferences, messages: List<ChatMessage>) {
    val array = JSONArray()
    messages.takeLast(100).forEach { array.put(JSONObject().put("role", it.role).put("content", it.content)) }
    prefs.edit().putString("history", array.toString()).apply()
}

private fun loadMessages(prefs: android.content.SharedPreferences): List<ChatMessage> {
    return try {
        val array = JSONArray(prefs.getString("history", "[]"))
        (0 until array.length()).mapNotNull { i ->
            val item = array.optJSONObject(i) ?: return@mapNotNull null
            val role = item.optString("role")
            val content = item.optString("content")
            if (role in listOf("user", "assistant") && content.isNotBlank()) ChatMessage(role, content) else null
        }
    } catch (_: Exception) {
        emptyList()
    }
}
