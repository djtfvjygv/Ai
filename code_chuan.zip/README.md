# AXIOM Android APK

Ứng dụng Android native viết bằng Kotlin + Jetpack Compose. Ứng dụng kết nối tới Ollama qua HTTP API và lưu tối đa 100 tin nhắn gần nhất trên thiết bị.

## Yêu cầu build
- Android Studio Ladybug hoặc mới hơn
- JDK 17
- Android SDK Platform 35
- Gradle 8.9+ (Android Gradle Plugin 8.7.3)

## Build APK
1. Giải nén dự án và mở thư mục `axiom_android` bằng Android Studio.
2. Chờ Gradle Sync hoàn tất.
3. Chọn **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. APK debug nằm tại `app/build/outputs/apk/debug/app-debug.apk`.

Hoặc trong terminal:
```bash
gradle assembleDebug
```

## Kết nối tới Ollama trên máy tính cùng Wi-Fi
1. Cài Ollama trên máy tính và tải model:
   `ollama pull llama3.2:3b`
2. Cho Ollama lắng nghe trên mạng LAN, ví dụ trên Linux/macOS:
   `OLLAMA_HOST=0.0.0.0:11434 ollama serve`
   Trên Windows, đặt biến môi trường `OLLAMA_HOST=0.0.0.0:11434` rồi khởi động lại Ollama.
3. Cho phép cổng TCP 11434 qua firewall **chỉ trong mạng riêng đáng tin cậy**.
4. Tìm IPv4 LAN của máy tính, ví dụ `192.168.1.10`.
5. Điện thoại và máy tính phải cùng Wi-Fi. Trong AXIOM > Cài đặt AI, nhập:
   - URL: `http://192.168.1.10:11434`
   - Model: `llama3.2:3b`
6. Nhấn **Kiểm tra kết nối**, sau đó lưu.

Không mở cổng Ollama trực tiếp ra Internet. Ollama mặc định không có lớp xác thực phù hợp để phơi ra mạng công cộng. Chỉ cho phép truy cập từ mạng LAN tin cậy.

## Giới hạn bản 1.0
- Đây là ứng dụng Android native, nhưng suy luận AI chạy trên máy có Ollama, không chạy trực tiếp trong APK.
- Cần Wi-Fi/LAN kết nối tới máy chủ Ollama.
- Chưa có streaming token, đăng nhập, đồng bộ cloud hoặc mã hóa lịch sử.
- Dự án source chưa kèm Android SDK, Gradle wrapper JAR hoặc APK đã biên dịch. Cần build bằng Android Studio/Gradle trên máy có Android SDK.
- Cho bản phát hành công khai, nên chuyển kết nối sang HTTPS hoặc VPN riêng và bổ sung xác thực.

## Cấu trúc
- `app/src/main/java/com/axiom/local/MainActivity.kt`: giao diện, cài đặt, gọi API, lưu lịch sử.
- `app/src/main/AndroidManifest.xml`: quyền Internet và cấu hình ứng dụng.
- `app/build.gradle.kts`: cấu hình build và thư viện.

## Tạo APK tự động bằng GitHub Actions

Nếu bạn chưa cài Android Studio:
1. Tạo một repository GitHub mới và tải toàn bộ nội dung thư mục `axiom_android` lên repository đó.
2. Mở tab **Actions** của repository.
3. Chọn workflow **Build AXIOM APK** rồi nhấn **Run workflow** (hoặc push code lên nhánh `main`/`master`).
4. Khi workflow chạy xong, mở lần chạy thành công và tải artifact **AXIOM-debug-apk** trong phần Artifacts.
5. Giải nén artifact; file cài đặt là `app-debug.apk`.

Đây là APK debug để thử nghiệm. Android có thể yêu cầu cho phép cài ứng dụng từ nguồn bạn dùng để tải file.
